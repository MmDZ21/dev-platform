-- AlterTable
ALTER TABLE "Post" ADD COLUMN     "draft" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "summary" TEXT;
