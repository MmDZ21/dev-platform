-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "ogTitle" TEXT;
