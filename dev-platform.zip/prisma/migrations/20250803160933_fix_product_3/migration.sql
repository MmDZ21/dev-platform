-- AlterTable
ALTER TABLE "Product" ADD COLUMN     "ogDescription" TEXT;
