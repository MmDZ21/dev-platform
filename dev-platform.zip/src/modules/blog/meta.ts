import { PenIcon } from "lucide-react";

export const blogMeta = {
  name: "بلاگ",
  icon: PenIcon
};