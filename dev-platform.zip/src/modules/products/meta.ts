import { PenIcon } from "lucide-react";

export const productsMeta = {
  name: "محصولات",
  icon: PenIcon
};